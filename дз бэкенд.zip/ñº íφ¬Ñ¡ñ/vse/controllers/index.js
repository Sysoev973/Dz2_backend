const mainRouteController = require('./main');
const gameRouteController = require('./game');
const defaultRouteController = require('./default');
const voteRouterController = require('./vote');


module.exports = {
    mainRouteController,
    gameRouteController,
    voteRouterController,
    defaultRouteController,
};